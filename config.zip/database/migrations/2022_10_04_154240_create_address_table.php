<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAddressTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('address', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('user_id');
            $table->string('address_label');
            $table->string('name');
            $table->string('phone_number');
            $table->longText('address');
            $table->longText('complete_address');
            $table->longText('address_detail');
            $table->boolean('choice')->default(false);
            $table->bigInteger('postcode');
            $table->string('district');
            $table->bigInteger('city_id');
            $table->bigInteger('province_id');
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('address');
    }
}
