<?php

namespace App\Http\Controllers\API;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Http\Controllers\Controller;
use App\Models\ProductGallery;
use App\Http\Requests\ProductGalleryRequest;
use App\Models\Product;

class ProductGalleryController extends Controller
{
    public function upload(ProductGalleryRequest $request, Product $product)
    {
        $files = $request->file('files');

        if($request->hasFile('files'))
        {
            foreach ($files as $file) {
                $path = $file->store('public/gallery');

                ProductGallery::create([
                    'products_id' => $product->id,
                    'url' => $path
                ]);
            }
             return["result"=> $path];
        }  // if ($request->hasFile('image1')){
        //     $image = new ProductGallery();
        //     $image->products_id = $request ->id;
        //     $path = $request->file('image1')->store('productGalleries');
        //     $image->url = $path;
        //     $image->save();
        // }

        //    if ($request->hasFile('image2')){
        //     $image = new ProductGallery();
        //     $image->products_id = $request ->id;
        //     $path = $request->file('image2')->store('productGalleries');
        //     $image->url = $path;
        //     $image->save();
        // }

        //    if ($request->hasFile('image3')){
        //     $image = new ProductGallery();
        //     $image->products_id = $request ->id;
        //     $path = $request->file('image3')->store('productGalleries');
        //     $image->url = $path;
        //     $image->save();
        // }

        //    if ($request->hasFile('image4')){
        //     $image = new ProductGallery();
        //     $image->products_id = $request ->id;
        //     $path = $request->file('image4')->store('productGalleries');
        //     $image->url = $path;
        //     $image->save();
        // }

        //    if ($request->hasFile('image5')){
        //     $image = new ProductGallery();
        //     $image->products_id = $request ->id;
        //     $path = $request->file('image5')->store('productGalleries');
        //     $image->url = $path;
        //     $image->save();
        // }

        //    if ($request->hasFile('image6')){
        //     $image = new ProductGallery();
        //     $image->products_id = $request ->id;
        //     $path = $request->file('image6')->store('productGalleries');
        //     $image->url = $path;
        //     $image->save();
        // }

        //    if ($request->hasFile('image7')){
        //     $image = new ProductGallery();
        //     $image->products_id = $request ->id;
        //     $path = $request->file('image7')->store('productGalleries');
        //     $image->url = $path;
        //     $image->save();
        // }

        // return["result"=> $image];
    }


}
