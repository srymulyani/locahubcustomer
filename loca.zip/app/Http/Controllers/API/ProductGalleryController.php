<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Http\Controllers\Controller;
use App\Models\ProductGallery;


class ProductGalleryController extends Controller
{
    public function upload(Request $request)
    {
        $images = [];

         if ($request->hasFile('image1')) {
        $image = new ProductGallery();
        $image->products_id = $request->id;
        $path = $request->file('image1')->store('public/images');
        $url = env('APP_URL') . Storage::url($path);
        $image->url = $url;
        $image->save();
        $images[] = $image;
    }

       if ($request->hasFile('image2')) {
        $image = new ProductGallery();
        $image->products_id = $request->id;
        $path = $request->file('image2')->store('public/images');
        $url = env('APP_URL') . Storage::url($path);
        $image->url = $url;
        $image->save();
        $images[] = $image;
    }
      return ["result" => $images];
    }
}

    

